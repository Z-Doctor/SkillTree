package zdoctor.skilltree.api.enums;

public enum SkillFrameType {
	NORMAL,
	SPECIAL,
	ROUNDED,
	NONE
}
