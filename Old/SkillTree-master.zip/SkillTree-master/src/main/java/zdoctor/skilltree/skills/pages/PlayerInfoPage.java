package zdoctor.skilltree.skills.pages;

public class PlayerInfoPage extends SkillPageBase {

	public PlayerInfoPage() {
		super("PlayerInfo");
	}
	
	@Override
	public void registerSkills() {
		
	}

	@Override
	public void loadPage() {

	}
}
