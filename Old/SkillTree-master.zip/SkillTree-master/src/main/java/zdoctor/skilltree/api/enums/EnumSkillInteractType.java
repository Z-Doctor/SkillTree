package zdoctor.skilltree.api.enums;

public enum EnumSkillInteractType {
	BUY,
	SELL,
	REFUND,
	TOGGLE
}
