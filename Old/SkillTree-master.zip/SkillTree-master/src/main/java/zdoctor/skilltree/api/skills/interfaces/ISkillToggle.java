package zdoctor.skilltree.api.skills.interfaces;

public interface ISkillToggle {
	
}
