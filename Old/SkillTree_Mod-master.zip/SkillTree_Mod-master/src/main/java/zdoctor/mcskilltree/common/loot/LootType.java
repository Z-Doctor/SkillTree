package zdoctor.mcskilltree.common.loot;

public enum LootType {
    EMPTY,
    ENTITY,
    BLOCK,
    CHEST,
    FISHING,
    GIFT,
    ADVANCEMENT_REWARD,
    BARTER,
    GENERIC
}
